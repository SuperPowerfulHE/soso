*Producer: SuperPowerfulHe
↓
Contact information:
*E-mail: chenpeiqi0319@gmail.com
*WeChat Customer service: https://work.weixin.qq.com/kfid/kfc455289204fe91499


*Voice sourse: Luo Huimin
↓
Contact information:
*E-mail: 3368566839@qq.com



Attention:

The voice pack has been made with Luo Huimin's consent.


SuperPowerfulHe is only responsible for production, and Luo Huimin has the final right of interpretation.